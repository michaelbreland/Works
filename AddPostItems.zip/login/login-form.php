<?php include('../header.php') ?>
<p>&nbsp;</p>
<form id="loginForm" name="loginForm" method="post" action="login-exec.php"  onSubmit="return validate()">
  <table width="300" border="0" align="center" cellpadding="2" cellspacing="0">
    <tr>
      <td width="112"><b>Login</b></td>
      <td width="188"><input name="username" type="text" class="textfield" id="username" /></td>
    </tr>
    <tr>
      <td><b>Password</b></td>
      <td><input name="password" type="password" class="textfield" id="password" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Login" /></td>
    </tr>
  </table>
</form>
<?php include('../footer.php') ?>
