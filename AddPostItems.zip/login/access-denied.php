<?php include('../header.php'); ?>
<h1>Access Denied </h1>
<p align="center">&nbsp;</p>
<h4 align="center" class="err">Access Denied!<br />
  You do not have access to this resource.</h4><br>
  <p align="center">Click here to <a href="login-form.php">Login</a></p>
<?php include('../footer.php') ?>
