<?php include('../header.php'); ?>

<h1>Login Failed </h1>
<p align="center">&nbsp;</p>
<h4 align="center" class="err">Login Failed!<br />
  Please check your username and password</h4>
  <p align="center">Click here to <a href="login-form.php">Login</a></p>

<?php include('../footer.php') ?>
